=====
BCF CAS
=====

bcf-cas is a package to enable CAS authentication.

Quick start
-----------

1. Add "polls" to your INSTALLED_APPS setting::

    INSTALLED_APPS = (
        ...
        'bcf-cas',
    )

2. Include the polls URLconf in your project urls.py::

    url(r'^$', include('bcf-cas.urls')),

3. Include the authentication backend in your settings.py::

    AUTHENTICATION_BACKENDS = (
        ...
        'bcf-cas.backends.CASBackend',
    )

4. Include the CAS middleware::

    MIDDLEWARE_CLASSES = (
        ...
        'cas.middleware.CASMiddleware',
    )

5. Include the CAS settings in settings.py::

    CAS_SERVER_URL = 'https://webauth.arizona.edu/webauth/validate'
    CAS_LOGOUT_COMPLETELY = True
    CAS_PROVIDE_URL_TO_LOGOUT = True
